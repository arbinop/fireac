if GenScripts.Language ~= 'de' then
    return
end

Locales = {
    ["pause_menu"] = "Pausemenü",
    ["gtav"] = "GEN",
    ["map"] = "KARTE",
    ["map_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["character"] = "CHARAKTER",
    ["information"] = "INFORMATION",
    ["charinfo_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["name"] = "NAME",
    ["job"] = "BERUF",
    ["birthday"] = "GEBURTSTAG",
    ["totaltime"] = "GESAMTSPIELZEIT",
    ["gender"] = "GESCHLECHT",
    ["male"] = "MÄNNLICH",
    ["female"] = "WEIBLICH",
    ["steam_account"] = "SPIELER",
    ["settings"] = "EINSTELLUNGEN",
    ["settings_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["money"] = "GELD",
    ["information2"] = "INFORMATION",
    ["bank_amount"] = "BANKBETRAG",
    ["wallet_amount"] = "BARGELDBETRAG",

}
