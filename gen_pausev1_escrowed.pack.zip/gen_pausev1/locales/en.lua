if GenScripts.Language ~= 'en' then
    return
end

Locales = {
    ["pause_menu"] = "Pause Menu",
    ["gtav"] = "GEN",
    ["map"] = "MAP",
    ["map_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["character"] = "CHARACTER",
    ["information"] = "INFORMATION",
    ["charinfo_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["name"] = "NAME",
    ["job"] = "JOB",
    ["birthday"] = "BIRTH DAY",
    ["totaltime"] = "TOTAL PLAY",
    ["gender"] = "GENDER",
    ["male"] = "MALE",
    ["female"] = "FEMALE",
    ["steam_account"] = "PLAYER",
    ["settings"] = "SETTINGS",
    ["settings_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["money"] = "MONEY",
    ["information2"] = "INFORMATION",
    ["bank_amount"] = "BANK AMOUNT",
    ["wallet_amount"] = "WALLET AMOUNT",

}
