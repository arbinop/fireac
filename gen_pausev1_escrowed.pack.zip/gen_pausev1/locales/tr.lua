if GenScripts.Language ~= 'tr' then
    return
end

Locales = {
    ["pause_menu"] = "Pause Menu",
    ["gtav"] = "GEN",
    ["map"] = "HARITA",
    ["map_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["character"] = "KARAKTER",
    ["information"] = "BILGISI",
    ["charinfo_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["name"] = "ISIM",
    ["job"] = "MESLEK",
    ["birthday"] = "DOGUM GUNU",
    ["totaltime"] = "OYUN SURESI",
    ["gender"] = "CINSIYET",
    ["male"] = "ERKEK",
    ["female"] = "KADIN",
    ["steam_account"] = "OYUNCU",
    ["settings"] = "AYARLAR",
    ["settings_description"] = "Lorem ipsum dolor sit amet consectetur. Consectetur tempus feugiat pulvinar felis id mi.",
    ["money"] = "PARA",
    ["information2"] = "BILGILERI",
    ["bank_amount"] = "BANKA",
    ["wallet_amount"] = "CUZDAN",

}
