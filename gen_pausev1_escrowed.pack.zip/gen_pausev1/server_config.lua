SteamApiKey = "CHANGE_THIS" -- https://steamcommunity.com/dev
Token = "MTIyOTk0MzkyMjYwMDQ0MzkzNA.GMTnYB.BzyyMAIUYj7apM6VNyqdzwb_G2gwpq2DL6mEss" -- Discord Bot Token